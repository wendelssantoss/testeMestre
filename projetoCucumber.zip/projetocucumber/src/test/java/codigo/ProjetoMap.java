package codigo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProjetoMap extends Metodos{

	@FindBy(id= "username")
	protected WebElement username;
	@FindBy(id= "password")
	protected WebElement password;
	@FindBy(name= "login")
	protected WebElement login;
	@FindBy(id= "concursos")
	protected WebElement concursos;
	@FindBy(id= "acompanhar")
	protected WebElement acompanhar;

}
