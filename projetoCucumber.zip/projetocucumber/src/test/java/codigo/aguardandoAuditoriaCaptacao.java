package codigo;


import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class aguardandoAuditoriaCaptacao {

	public Metodos me = new Metodos();
	
	@Given("^Acesso a pagina inicial$")
	public void acesso_a_pagina_inicial() {
		System.setProperty("webdriver.chrome.driver", "..\\projetocucumber\\Drivers\\chromedriver.exe");
		me.driver = new ChromeDriver();
		me.driver.manage().window().maximize();
		me.driver.get("https://login.hmp.caixa/auth/realms/intranet/protocol/openid-connect/auth?client_id=cli-web-spl&redirect_uri=http%3A%2F%2Fsbrdeapllx061.extra.caixa.gov.br%3A13580%2Fsispl-gestao-web%2F%3Ferror%3Dinvalid_request%26error_description%3DMissing%2Bparameter%253A%2Bresponse_type&state=e6666fe2-3a7b-4b60-b40c-2c6817266bb1&nonce=8ef2877d-6dfa-4a67-a9bf-0c2d25fcf07d&response_mode=fragment&response_type=code&scope=openid");
	}
	@Given("^Entro com usuario e senha$")
	public void entro_com_usuario_e_senha()  {
		me.driver.findElement(By.id("username")).sendKeys("c893582");
		me.driver.findElement(By.id("password")).sendKeys("8HcRkWQc");
		me.driver.findElement(By.name("login")).click();
	}
	@Given("^Clico no menu Concursos$")
	public void clico_no_menu_Concursos() throws InterruptedException  {
		me.aguardarCmd("Aguarde a apresentação do menu para continuar...");
		me.driver.findElement(By.id("concursos")).click();
	}

	@When("^Clico no submenu Acompanhar$")
	public void clico_no_submenu_Acompanhar() throws InterruptedException  {
		me.driver.findElement(By.id("acompanhar")).click();
		Thread.sleep(20000);
	}
	@Then("^Verifico o status$")
	public void verifico_o_status()  {
		me.assertMensagem(By.cssSelector("#tableAcompanharConcursos > tbody > tr:nth-child(2) > td:nth-child(5)"), "Aguardando Auditoria da Captação");
	
	}
}
