package codigo;

import java.util.Scanner;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;


public class Metodos {

	public WebDriver driver;
	
	public void selecionaCombo(By by, String texto) {
		new Select(driver.findElement(by)).selectByVisibleText(texto);
	}
	public void clicarObjeto(By by) {
		driver.findElement(by).click();
	}
	public void inserirTexto(By by, String texto) {
		driver.findElement(by).sendKeys(texto);
	}
	 /**
	    * CLICA EM UM OBJETO PASSANDO COMO PARAMETRO COMANDOS JAVASCRIPT
	    * Ex.:clicarObjetoJS("passa o by do objeto", "passa o comando JS")
	    * @param by
	    * @param JS
	    */
		public void inserirTextoJS(By by, String JS) {
			
			WebElement texto = driver.findElement(by);
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript(JS, texto);
		}
		public void aguardarCmd(String mensagem) {
			
	        Scanner s=new Scanner(System.in);

	        System.out.println(mensagem);

	        s.nextLine();

	    }
		/**
		 * VALIDA MENSAGEM PASSANDO COMO PARÂMETRO O MENSAGEM ESPERADA E A ID DA MENSAGEM 
		 * Ex.:validarMensagem("mensagem esperada"(TEXTO) ,apresentada(BY));
		 * @param id
		 * @param mensagem
		 */
		public void validarMensagemId(String esperada, By apresentada) {

				try {
					Assert.assertEquals(esperada,driver.findElement(apresentada).getText());
//					geraMensagem("Mensagem correta!");
					System.out.println("Mensagem correta!");
				} catch (Error e) {
					System.out.println("Mensagem incorreta!");
				}
	}
		public void assertMensagem(By mensagemTela, String mensagemEspe) {
			String mensagem = driver.findElement(mensagemTela).getText();//GUARDA O VALOR DO TITULO	
			if (mensagem.equals(mensagemEspe)){
				System.out.println("Validado com sucesso!");				
				}else {
					System.out.println("ERRO na validação!");
				}

		}



}
