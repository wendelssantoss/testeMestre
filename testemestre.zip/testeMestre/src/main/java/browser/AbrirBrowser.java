package browser;


import org.openqa.selenium.chrome.ChromeDriver;

public class AbrirBrowser extends Metodos{

	public void setup() {
		System.setProperty("webdriver.chrome.driver", "..\\testeMestre\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
//		driver.manage().window().maximize();
		driver.get("https://www.google.com");foto();
	}
}
