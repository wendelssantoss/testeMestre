package browser;

import java.io.IOException;

import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import auxiliaresWeb.GeradorPDF;

public class CT01_Teste extends Metodos{

	public AbrirBrowser url = new AbrirBrowser();
	
	@Test
	public void test() throws InterruptedException {
		
	url.setup();
		
	driver.findElement(By.name("q")).sendKeys("teste novo 123456789"+Keys.ENTER);
	foto();
	
	Thread.sleep(5000);
	
	validarMensagem("Vídeos", By.cssSelector("#rso > div:nth-child(1) > div > div > div > div > div.Nxb87 > div > title-with-lhs-icon > div.iJ1Kvb > h3"));
	
	}

	@After
	public void sair() throws IOException, InterruptedException {
	    Thread.sleep(5000);  
	    driver.quit();
	    GeradorPDF.geraPdf("Teste.pdf", "Sprint 1");

	}

	}


