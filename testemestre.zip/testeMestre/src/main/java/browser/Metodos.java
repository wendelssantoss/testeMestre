package browser;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Metodos {

	public static WebDriver driver;
	
	/**
	 * METODO USADO PARA TIRAR PRINT DA AÇÃO
	 * DEVE SER COLOCADO APOS O MÉTODO
	 * 
	 * @return
	 */
	public static String foto() {

		File printFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyy-hh-mm-ss");
		Date d = new Date();
		String data = dateFormat.format(d);
		String nomeImagem = data + ".jpeg";

		try {
			FileUtils.copyFile(printFile, new File("C:\\Desenvolvimento\\screenshot\\" + nomeImagem));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return nomeImagem;
	}
	public void inserirTextoCampo(By by, String texto) {
		
		WebElement inserir = driver.findElement(by);
		inserir.sendKeys(texto);foto();

	}
	public void clicarObjeto(By by) {
		WebElement pesquisa = driver.findElement(by);
		pesquisa.click();foto();
	}
	public void validarMensagem(String texto, By by) {
		try {
			Assert.assertEquals(texto,driver.findElement(by).getText());
			System.out.println("Mensagem correta");foto();	
		} catch (Exception e) {
			System.out.println("Mensagem incorreta");
		}

	}

}
