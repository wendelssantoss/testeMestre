package testesMobile;

import java.io.IOException;
import java.net.MalformedURLException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;

import auxiliaresMobile.Instancias;
import auxiliaresMobile.StartApp;
import auxiliaresMobile.SuperClasseMobile;
import auxiliaresWeb.GeradorPDF;
import jxl.read.biff.BiffException;

public class CT01_Login extends SuperClasseMobile{


	public Instancias insta = new Instancias();
	
	@Before
	public void setup() throws MalformedURLException, InterruptedException {

		this.insta.driver = StartApp.startApp();
		SuperClasseMobile.driver = insta.driver;
	}
	@Test
	public void test() throws BiffException, IOException, Exception {
		foto();
		Thread.sleep(5000);
		try {
			validarMensagemId(excel.getElementos(16, 2), By.id(excel.getElementos(42, 1)));
			clicaObjExcelId(39, 1);foto();

		} catch (Exception e) {
			validarMensagemId(excel.getElementos(17, 2), By.id(excel.getElementos(40, 1)));
			clicaObjExcelId(41, 1);
		}
	}
	@After
	public void sair() throws IOException, InterruptedException {
	    
	    driver.quit();
	    GeradorPDF.geraPdf("Login.pdf", "Sprint 1");

	}

}
