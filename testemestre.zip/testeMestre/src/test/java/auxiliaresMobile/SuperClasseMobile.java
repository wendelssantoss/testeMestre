package auxiliaresMobile;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.codehaus.plexus.util.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Strings;

import atu.testrecorder.ATUTestRecorder;
import auxiliaresWeb.Evidencia;
import auxiliaresWeb.ExecutarCmd;
import auxiliaresWeb.LeitorExcel;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import jxl.read.biff.BiffException;;

public class SuperClasseMobile {

	protected static LeitorExcel excel = new LeitorExcel();
	public ExecutarCmd cmd = new ExecutarCmd();
	protected static final int SEG = 1;
	protected static final int MIN = 1000;
	protected static final int HOR = 1000 * 60;
	protected static final String VIRGULA = ";";
	protected static ATUTestRecorder recorder;
	public static  AndroidDriver<MobileElement> driver;
	protected WebDriverWait wait;

	static List<Evidencia> evidencias = new ArrayList<>();
	
	
	
	/*******************************************************************************************
	 * SERVE PARA INSERIR TEXTO AO CAMPO PASSANDO COMO PARÂMETRO o BY E O TEXTO
	 * EXEMPLO: inserirTextoCampo(By.xpath(""), "texto");
	 * 
	 * @param link
	 */
	
	public void inserirTextoCampo(By by, String texto) {
		
		MobileElement element = driver.findElement(by);
		if(element.isDisplayed()) {
			element.clear();
			element.sendKeys(texto);foto();
		}
	}

	/*******************************************************************************************
	 * SERVE PARA CLICAR NO OBJETO PASSANDO COMO PAR�METRO O BY 
	 *  EXEMPLO: clicarObjeto(By.xpath("propriedade do objeto"));
	 * 
	 * @param link
	 */
	public  void clicarObjeto(By by) {
		MobileElement element = driver.findElement(by);
		if(element != null && element.isDisplayed()) {
			element.click();
		}
		
	}
	/**
	 * MÉTODO PARA INFORMAR AS POSIÇÕES DE LINHAS (l) E COLUNAS (c) E O COMANDO JAVASCRIPT
	 * ONDE ESTÃO OS ELEMENTOS (e) DO By.name NO EXCEL PARA CLICAR NO OBJETO
	 * EXEMPLO: clicaObjExcelJsName(1,1,1,1));
	 * @param le
	 * @param ce
	 * @throws BiffException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void clicaObjExcelJsName(int le, int ce, int ljs, int cjs) throws BiffException, IOException, InterruptedException {
		clicarObjetoJS(By.name(excel.getElementos(le, ce)), excel.getElementos(ljs, cjs));	
	}
	/**
	 * MÉTODO PARA INFORMAR AS POSIÇÕES DE LINHAS (l) E COLUNAS (c) 
	 * ONDE ESTÃO OS ELEMENTOS (e) DO By.cssSelector NO EXCEL PARA CLICAR NO OBJETO
	 * EXEMPLO: clicaObjExcelCss(1,1));
	 * @param le
	 * @param ce
	 * @throws BiffException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void clicaObjExcelCss(int le, int ce) throws BiffException, IOException, InterruptedException {
		clicarObjeto(By.cssSelector(excel.getElementos(le, ce)));
	}
	/**
	 * MÉTODO PARA INFORMAR AS POSIÇÕES DE LINHAS (l) E COLUNAS (c) 
	 * ONDE ESTÃO OS ELEMENTOS (e) DO By.id NO EXCEL PARA CLICAR NO OBJETO
	 * EXEMPLO: clicaObjExcelId(1,1));
	 * @param le
	 * @param ce
	 * @throws BiffException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void clicaObjExcelId(int le, int ce) throws BiffException, IOException, InterruptedException {
		clicarObjeto(By.id(excel.getElementos(le, ce)));foto();
	}

	/**
	 * MÉTODO PARA INFORMAR AS POSIÇÕES DE LINHAS (l) E COLUNAS (c) 
	 * ONDE ESTÃO OS ELEMENTOS (e) DO By.xpath NO EXCEL PARA CLICAR NO OBJETO
	 * EXEMPLO: clicaObjExcelXpath(1,1));
	 * @param le
	 * @param ce
	 * @throws BiffException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void clicaObjExcelXpath(int le, int ce) throws BiffException, IOException, InterruptedException {
		clicarObjeto(By.xpath(excel.getElementos(le, ce)));
	}
	/**
	 * MÉTODO PARA INFORMAR AS POSIÇÕES DE LINHAS (l) E COLUNAS (c) 
	 * ONDE ESTÃO OS ELEMENTOS (e) DO By.xpath NO EXCEL PARA SELECIONAR OPÇÃO
	 * EXEMPLO: clicaObjExcelCss(1,1));
	 * @param le
	 * @param ce
	 * @throws BiffException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void SeleCombExcelCss(int le, int ce, int lm, int cm) throws BiffException, IOException, InterruptedException {
		selecionaComboBy(By.cssSelector(excel.getElementos(le, ce)),excel.getElementos(lm, cm));
	}
	/*******************************************************************************************
	 * SERVE PARA SELECIONAR O OBJETO COM O BY, PASSANDO COMO PAR�METRO O
	 * BY E O VALOR A SER SELECIONADO EXEMPLO: selecionaComboBy(by.id(""), "teste");
	 * 
	 * @param id
	 * @param valor
	 * @throws InterruptedException
	 */
	public void selecionaComboBy(By by, String valor) throws InterruptedException {
		
		MobileElement element = driver.findElement(by);
		element.click();
		element.sendKeys(valor);
		element.sendKeys(Keys.TAB);
	}

	/**
	 * ESPERA O ELEMENTO FICAR VISIVEL, PRESENTE E CLICAVEL USANDO COMO
	 * PARAMETRO O TEMPO E O BY
	 * Ex.: esperaClique(900000000,By.xpath("/euhuihihiuhfi/"));
	 * @param tempo
	 * @param by
	 */
	public void esperaClique(int tempo, By by) {
		
			WebDriverWait wait = new WebDriverWait(driver, tempo*1000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(by)).click();
			foto();
			
	}

	/*******************************************************************************************
	 * SERVE PARA SELECIONAR A COMBOBOX, PASSANDO COMO PAR�METRO O BY
	 * E O VALOR A SER SELECIONADO EXEMPLO: selecionaCombo("comboid",
	 * "teste");
	 * 
	 * @param id
	 * @param valor
	 * @throws InterruptedException
	 */
	public  void selecionaCombo(By by, String valor) throws InterruptedException {
		
		MobileElement element = driver.findElement(by);
		element.click();
		element.sendKeys(valor);
		element.sendKeys(Keys.TAB);
	}
	/*******************************************************************************************
	 * SERVE PARA PRINTAR AS AÇÕES EM TELA 
	 * 
	 * @throws IOException
	 */
	public  String foto() {

		File printFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyy-hh-mm-ss");
		Date d = new Date();
		String data = dateFormat.format(d);
		String nomeImagem = data + ".jpeg";

		try {
			FileUtils.copyFile(printFile, new File("C:\\Desenvolvimento\\screenshot\\" + nomeImagem));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return nomeImagem;
	}
	public  void logoff (String menususp, String sair) {
		
		MobileElement menu = driver.findElement(By.xpath(menususp));
		menu.click();
		MobileElement saida = driver.findElement(By.xpath(sair));
		saida.click();
	
		
	}
	public  void geraMensagem (String mensagem) {
		
		Evidencia evidencia = new Evidencia();
		evidencia.setMensagem(mensagem);
		evidencia.setImagem(foto());
		evidencias.add(evidencia);
		System.out.println(mensagem);
	
	}
	/*******************************************************************************************
	 * ESTE MÉTODO INSERE A MENSAGEM EM UM ARQUIVO
	 * 
	 * @param driver
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws FileNotFoundException
	 */
	public  String getMensagemEvidencia(String nomeImagem) {
		for(Evidencia evidencia : evidencias) {
			if(evidencia.getImagem().equals(nomeImagem))
				return evidencia.getMensagem();
		}
		return null;
	}
	public  void assertMensagem(String mensagemTela, String mensagemEspe) {
		String textTitulo = driver.findElement(By.xpath(mensagemTela.trim())).getText();//GUARDA O VALOR DO TITULO	
		if (textTitulo.equals(mensagemEspe)){
			geraMensagem("Validado com sucesso!");				
			}else {
				geraMensagem("ERRO na validação!");
			}

	}
	 /**
	    * CLICA EM UM OBJETO PASSANDO COMO PARAMETRO COMANDOS JAVASCRIPT
	    * Ex.:clicarObjetoJS("passa o by do objeto", "passa o comando JS")
	    * @param by
	    * @param JS
	    */
		public  void clicarObjetoJS(By by, String JS) {
			
			MobileElement button = driver.findElement(by);
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript(JS, button);
		}
		/**
		 * FAZ A ROLAGEM DE TELA PASSANDO COMO PARAMETRO A QUANTIDADE DE REPETIÇOES, A PORCENTAGEM QUE IRA ROLA
		 * E O BY 
		 * Ex.:validarMensagem(2, 0.4 , By.xpath("/grititit/"));
		 * @param PorcRolar
		 * @param by
		 * @return
		 * @throws Exception
		 */
		public  boolean rolagemTela (int qtd, Double PorcRolar, By by) throws Exception {
		//EXISTE NA TELA?
		boolean isFoundTheElement = driver.findElements(by).size() > 0;
		//NAO EXISTE
//		while (isFoundTheElement == false) {
		//SE NAO EXISTE CONTINUA PROCURANDO	
		for(int i=0; i<=qtd; i++) {
			swipeVertical(PorcRolar, 0.1, 0.5, 2000);
		}
		
//		isFoundTheElement = driver.findElements(by).size() > 0;
		
//		}
//		MobileElement clicar = driver.findElement(by);
//		clicar.click();
				  return isFoundTheElement;
				}
		public  void swipeVertical (
		  double startPercentage, double finalPercentage, double anchorPercentage, int duration)
		  throws Exception {
		  org.openqa.selenium.Dimension size = driver.manage().window().getSize();
		  int anchor = (int) (size.width * anchorPercentage);
		  int startPoint = (int) (size.height * startPercentage);
		  int endPoint = (int) (size.height * finalPercentage);
		  getTouchAction().press(PointOption.point(anchor, startPoint))
		  .waitAction(WaitOptions.waitOptions(Duration.ofMillis(duration)))
		  .moveTo(PointOption.point(anchor, endPoint)).release().perform();
		  
		  
		}
		@SuppressWarnings("rawtypes")
		public  TouchAction getTouchAction () {
			
				  return new TouchAction(driver);
				  
				

		}
	
		/**
		 * VALIDA MENSAGEM PASSANDO COMO PARÂMETRO O MENSAGEM ESPERADA E A ID DA MENSAGEM 
		 * Ex.:validarMensagem("mensagem esperada"(TEXTO) ,apresentada(BY));
		 * @param id
		 * @param mensagem
		 */
		public void validarMensagemId(String esperada, By apresentada) {

				try {
					Assert.assertEquals(esperada,driver.findElement(apresentada).getText());	foto();
//					geraMensagem("Mensagem correta!");
					System.out.println("Mensagem correta!");
				} catch (Error e) {
					geraMensagem("Mensagem incorreta!");foto();
					System.out.println("Mensagem incorreta!");
				}
	}
		/*******************************************************************************************
		 * SERVE PARA COMPARAR SE O VALOR APRESENTADO É VERDADEIRO PASSANDO COMO
		 * PARÂMETRO TEXTO E O XPATH EXEMPLO: comparaValorId("valor", "elemento");
		 * 
		 * @param link
		 */
		public static void comparaValorId(String texto, By by) {
			try {
				Assert.assertEquals(texto,driver.findElement(by).getText());
					System.out.println("Mensagem correta");	
			} catch (Exception e) {
					System.out.println("Mensagem incorreta");
			}
			
		}

}
