package auxiliaresMobile;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

/**
 * CLASSE ONDE SERÁ STARTADA O APP NO EMULADOR
 * 
 * @author f604827
 *
 */

public class StartApp {

	public static  AndroidDriver<?> driver;

	public static AndroidDriver<MobileElement> startApp() throws MalformedURLException{
		//Nexus_6P_API_29
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceName", "Pixel_2_API_28");
		caps.setCapability("udid", "emulator-5554");
		caps.setCapability("platformName", "Android");
		caps.setCapability("platformVersion", "9.0");
		caps.setCapability("appPackage", "br.gov.caixa.loterias.apostas.hmp");
		caps.setCapability("appActivity", "br.gov.caixa.loterias.apostas.controllers.SplashScreenActivity");
		caps.setCapability("noReset", "true");
		return new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);


	}
	public AndroidDriver<MobileElement> startAppLoterias() throws MalformedURLException, InterruptedException{
			//Nexus_6P_API_29
//			AndroidDriver<MobileElement> driverAndroid = null;

			DesiredCapabilities capabilities = new DesiredCapabilities();
//			capabilities.setCapability ("AutomationName", "UiAutomator2");
		    capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "ANDROID");
			capabilities.setCapability(MobileCapabilityType.APP, "C:\\Users\\f604827\\Downloads\\hmp-1.0.44.4.apk");
			capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Nexus_5X_API_28");
			capabilities.setCapability(MobileCapabilityType.UDID, "emulator-5554"); 
			capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "9.0");
//			capabilities.setCapability(MobileCapabilityType.AUTO_WEBVIEW, true); 
			capabilities.setCapability("appPackage", "br.gov.caixa.loterias.apostas.hmp");
			capabilities.setCapability("appActivity", "br.gov.caixa.loterias.apostas.controllers.SplashScreenActivity");
		    return new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
//		    driverAndroid.context("WEBVIEW");
	}
}
