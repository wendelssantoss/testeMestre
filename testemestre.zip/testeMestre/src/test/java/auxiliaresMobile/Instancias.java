package auxiliaresMobile;


import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class Instancias extends SuperClasseMobile{

		/**
		 * INSTANCIAS NECESSARIAS PARA O REUSO DE CLASSES
		 */
		
		public AndroidDriver<MobileElement> driver;
		
		
		
	
}
