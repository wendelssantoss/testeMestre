package auxiliaresWeb;

import java.io.Console;
import java.util.Scanner;

import testesWeb.Suite_execucaoDaApuracao;

public class ExecutarCmd {


	
	public static void main(String[] args) throws Exception {
	
		Console console = System.console();
//		cpf = console.readLine("Informe seu cpf: ");
//		senha = new String(console.readPassword("Informe sua senha: "));
//		proposta = console.readLine("Informe o nome da proposta, caso necessário: ");
		

		Suite_execucaoDaApuracao.SuiteTestes(args[0]);
		
		
	}
	public void aguardarCmd(String mensagem) {
		
        Scanner s=new Scanner(System.in);

        System.out.println(mensagem);

        s.nextLine();

    }

}
