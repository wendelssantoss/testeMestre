package auxiliaresWeb;



import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

	public class GeradorPDF extends SuperClasse{

		public static void main(String[] args) throws IOException {
//			gerarPdf("teste.pdf");
		}

		/**
		 * MÉTODO PARA GERAR PDF 
		 * DEVE USADO AO FIM DA EXECUÇÃO DA FUNCIONALIDADE, OU SEJA,  NO AFTER DO JUNIT
		 * 
		 */
		
		public static void geraPdf(String nomeDocumento, String versao) throws IOException {

			
			Document d = new Document(PageSize.A4.rotate(), 10f, 10f, 10f, 0f);
			


			try {
				String caminhoPasta = "C:\\Desenvolvimento\\screenshot\\";
				String caminhoPDF = "C:\\Desenvolvimento\\";
				
				//AQUI SERÁ INSERIDO O NOME DO DOCUMENTO QUE SERÁ DEFINIDO PELO USUÁRIO
				PdfWriter pdfWriter = PdfWriter.getInstance(d, new FileOutputStream(caminhoPDF + nomeDocumento));
				d.open();
				//AQUI SERÁ DEFINIDO O CAMINHO DE ARMAZENAMENTO DAS IMAGENS PARA SEREM INSERIDAS NO PDF
				File pasta = new File(caminhoPasta);
				float widthPage = d.getPageSize().getWidth();
				
				/*
				 * CONFIGURAÇÕES DE FONTES PADRÕES PARA OS TEXTOS
				 */
				//VERSAO
				Font alteraFonteDadosVersao = new Font(Font.FontFamily.TIMES_ROMAN, 15, Font.BOLD);
				alteraFonteDadosVersao.setColor(BaseColor.GREEN);
				//EXECUÇÃO COM SUCESSO
				Font alteraFonteDados = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);
				alteraFonteDados.setColor(BaseColor.BLUE);
				//EXECUÇÃO COM ERRO
				Font alteraFonteDadosRed = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);
				alteraFonteDadosRed.setColor(BaseColor.RED);
				
				
				/*NESTA PARTE SERÃO COLHIDAS AS IMAGENS E TEXTOS NA PASTA DEFINIDA NA VARIÁVEL CAMINHO DA PASTA
				 * 
				 */
				for (String nomeArquivo : pasta.list()) {
					
					//AQUI ESTÃO SENDO DEFINIDAS AS CONFIGURAÇÕES DA TABELA
					PdfPTable table = new PdfPTable(1);
					table.setHorizontalAlignment(Element.ALIGN_CENTER);
					table.setWidthPercentage(100);//100
					table.setSpacingAfter(20);//20

					PdfPCell cell1 = new PdfPCell(new Phrase(versao, alteraFonteDadosVersao));
					cell1.setBorder(PdfPCell.LEFT | PdfPCell.TOP | PdfPCell.BOTTOM | PdfPCell.RIGHT);
					cell1.setBorderColor(BaseColor.BLUE);
					table.addCell(cell1);

					//AQUI ESTÃO SENDO PASSADOS AS CARACTERÍSTICAS PADRÕES DA TABELA QUE ESTARÃO NO PDF
					PdfPCell cell = new PdfPCell(new Phrase(nomeArquivo, alteraFonteDados));
					cell.setBorder(PdfPCell.LEFT | PdfPCell.TOP | PdfPCell.BOTTOM | PdfPCell.RIGHT);
					cell.setBorderColor(BaseColor.BLUE);
					table.addCell(cell);
					
					//ESTA VARIAVEL RETORNARÁ A MENSAGEM CORRESPONDENTE NO ARQUIVO
					String mensagem = getMensagemEvidencia(nomeArquivo);
					
					PdfPCell cellMensagem;
					if((mensagem != null && mensagem != "Validado com sucesso!")) {
						//CASO RETORNE ERRO NO ARQUIVO SERÁ INFORMADA A MENSAGEM ABAIXO
						cellMensagem = new PdfPCell(new Phrase(mensagem + "  -  NÃO OK", alteraFonteDadosRed));
						cellMensagem.setBorder(PdfPCell.LEFT | PdfPCell.TOP | PdfPCell.BOTTOM | PdfPCell.RIGHT);
						cellMensagem.setBorderColor(BaseColor.BLUE);
					} else {
						//CASO RETORNE SUCESSO SERÁ INFORMADA A MENSAGEM ABAIXO
						cellMensagem = new PdfPCell(new Phrase("OK", alteraFonteDados));
						cellMensagem.setBorder(PdfPCell.LEFT | PdfPCell.TOP | PdfPCell.BOTTOM | PdfPCell.RIGHT);
						cellMensagem.setBorderColor(BaseColor.BLUE);
					}
					table.addCell(cellMensagem);
					
					// AQUI SERÁ INSERIDO O NOME E TAMANHO E ONDE SERÁ RECUPERADA A IMAGEM
					Image image = Image.getInstance(caminhoPasta + nomeArquivo);
//					image.scaleAbsolute(widthPage - 590, widthPage / 2);
//					image.scaleAbsolute(360, 540);
					image.scaleAbsolute(640, 440);
//					image.scaleAbsolute(300, 480);//300  480
					PdfPCell cellImagem = new PdfPCell(image);
					cellImagem.setBorder(PdfPCell.LEFT | PdfPCell.TOP | PdfPCell.BOTTOM | PdfPCell.RIGHT);
					cellImagem.setBorderColor(BaseColor.BLUE);
//					cellImagem.setPaddingLeft(250);
					cellImagem.setPadding(65);
					table.addCell(cellImagem);
					d.add(table);
					d.newPage();
				}

			} catch (DocumentException de) {
				System.err.println(de.getMessage());
			} catch (IOException ioe) {
				System.err.println(ioe.getMessage());
			}
			d.close();
			deleteArquivo();
					
		}
		public static void deleteArquivo() {
			/*ESTE MÉTODO LIMPA OS ARQUIVOS DA PASTA ONDE ESTÃO AS IMAGENS DE PRINT
			 * 
			 */
			String pastaImagens = "C:\\Desenvolvimento\\screenshot\\";
//			File pasta = new File(pastaImagens);
//			pasta.deleteOnExit();
				
			File pasta = new File(pastaImagens);
			if (pasta.isDirectory()) {
				File[] sun = pasta.listFiles();
				for (File toDelete : sun) {
					toDelete.delete();
				}
			}
		}

		
	

}
