package auxiliaresWeb;

public class Evidencia {
	/**
	 * CLASSE CRIADA PARA IMPRIMIR IMAGEM NO DOCUMENTO DE EVIDÊNCIA, ONDE A MESMA É CHAMADA
	 */
	private String imagem;
	private String mensagem;
	
	public String getImagem() {
		return imagem;
	}
	public void setImagem(String imagem) {
		this.imagem = imagem;
	}
	public String getMensagem() {
		return mensagem;
	}
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

}
