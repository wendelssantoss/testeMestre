package auxiliaresWeb;

import java.io.IOException;

import jxl.read.biff.BiffException;

public class Menus extends SuperClasse{

	public static void menus() throws BiffException, IOException, InterruptedException {
		
		//CONCURSOS
		clicaObjExcelId(1, 1);foto();
		//ACOMPANHAR
		clicaObjExcelId(2, 1);foto();
		Thread.sleep(20000);

	}
}
