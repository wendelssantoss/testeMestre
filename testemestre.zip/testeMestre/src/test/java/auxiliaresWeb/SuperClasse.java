package auxiliaresWeb;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;


public class SuperClasse {

	
	protected static WebDriver driver=null;
	protected static LeitorExcel excel = new LeitorExcel();
	public ExecutarCmd cmd = new ExecutarCmd();

	static List<Evidencia> evidencias = new ArrayList<>();
	
	/**
	 * MÉTODO PARA INFORMAR AS POSIÇÕES DE LINHAS (l) E COLUNAS (c) 
	 * ONDE ESTÃO OS ELEMENTOS (e) E MASSAS (m) DO By.Name NO EXCEL
	 * PARA INSERIR INFORMAÇÃO NO CAMPO
	 * EXEMPLO: inseremassaTextoExcelName(1,1,2,2));
	 * @param le
	 * @param ce
	 * @param lm
	 * @param cm
	 * @throws BiffException
	 * @throws IOException
	 */
	public void insereMassaTextoExcelName(int le, int ce, int lm, int cm) throws BiffException, IOException {
		inserirTexto(By.name(excel.getElementos(le, ce)), excel.getElementos(lm, cm));
	}
	/**
	 * MÉTODO PARA INFORMAR AS POSIÇÕES DE LINHAS (l) E COLUNAS (c) 
	 * ONDE ESTÃO OS ELEMENTOS (e) DO By.Name NO EXCEL PARA CLICAR NO OBJETO
	 * EXEMPLO: clicaObjExcelName(1,1));
	 * @param le
	 * @param ce
	 * @return 
	 * @throws BiffException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void clicaObjExcelName(int le, int ce) throws BiffException, IOException, InterruptedException {
		clicarObjeto(By.name(excel.getElementos(le, ce)));
	}
	/**
 	 * MÉTODO PARA INFORMAR AS POSIÇÕES DE LINHAS (l) E COLUNAS (c) 
	 * ONDE ESTÃO OS ELEMENTOS (e) DO By.id NO EXCEL PARA CLICAR NO OBJETO
	 * EXEMPLO: inseremassaTextoExcelId(1,1,2,2));
	 * @param le
	 * @param ce
	 * @throws BiffException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static void clicaObjExcelId(int le, int ce) throws BiffException, IOException, InterruptedException {
		clicarObjeto(By.id(excel.getElementos(le, ce)));
	}
	/**
 	 * MÉTODO PARA CLICAR NO OBJETO
	 * PASSANDO COMO PARAMETRO O By
	 * EXEMPLO: clicarObjeto(By.xpath("valor"));
	 * @param by
	 * @throws InterruptedException
	 */
	public static void clicarObjeto(By by) throws InterruptedException {
		WebElement objeto = driver.findElement(by);
		objeto.click();
		Thread.sleep(5000);
	}
	/**
	 * MÉTODO PARA INFORMAR AS POSIÇÕES DE LINHAS (l) E COLUNAS (c) E O COMANDO JAVASCRIPT
	 * ONDE ESTÃO OS ELEMENTOS (e) DO By.name NO EXCEL PARA CLICAR NO OBJETO
	 * EXEMPLO: clicaObjExcelJsName(1,1,1,1));
	 * @param le
	 * @param ce
	 * @throws BiffException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void clicaObjExcelJsName(int le, int ce, int ljs, int cjs) throws BiffException, IOException, InterruptedException {
		clicarObjetoJS(By.name(excel.getElementos(le, ce)), excel.getElementos(ljs, cjs));	
	}
	/**
	 * MÉTODO PARA INFORMAR AS POSIÇÕES DE LINHAS (l) E COLUNAS (c) 
	 * ONDE ESTÃO OS ELEMENTOS (e) DO By.cssSelector NO EXCEL PARA CLICAR NO OBJETO
	 * EXEMPLO: clicaObjExcelCss(1,1));
	 * @param le
	 * @param ce
	 * @throws BiffException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void clicaObjExcelCss(int le, int ce) throws BiffException, IOException, InterruptedException {
		clicarObjeto(By.cssSelector(excel.getElementos(le, ce)));
	}
	/**
	 * MÉTODO PARA INFORMAR AS POSIÇÕES DE LINHAS (l) E COLUNAS (c) 
	 * ONDE ESTÃO OS ELEMENTOS (e) DO By.xpath NO EXCEL PARA CLICAR NO OBJETO
	 * EXEMPLO: clicaObjExcelXpath(1,1));
	 * @param le
	 * @param ce
	 * @throws BiffException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void clicaObjExcelXpath(int le, int ce) throws BiffException, IOException, InterruptedException {
		clicarObjeto(By.xpath(excel.getElementos(le, ce)));
	}
	/**
	 * MÉTODO PARA INFORMAR AS POSIÇÕES DE LINHAS (l) E COLUNAS (c) 
	 * ONDE ESTÃO OS ELEMENTOS (e) DO By.xpath NO EXCEL PARA SELECIONAR OPÇÃO
	 * EXEMPLO: clicaObjExcelCss(1,1));
	 * @param le
	 * @param ce
	 * @throws BiffException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void SeleCombExcelCss(int le, int ce, int lm, int cm) throws BiffException, IOException, InterruptedException {
		selecionaComboBy(By.cssSelector(excel.getElementos(le, ce)),excel.getElementos(lm, cm));
	}
	
	/**
 	 * MÉTODO PARA INSERIR INFORMAÇÃO EM UM CAMPO TEXTO
	 * PASSANDO COMO PARAMETRO O By E O TEXTO
	 * EXEMPLO: inserirTexto(By.xpath("valor"), "texto");
	 * @param by
	 * @param texto
	 */
	public void inserirTexto(By by, String texto) {
		WebElement usuario = driver.findElement(by);
	    usuario.sendKeys(texto);
	}
   public static void assertArrayEquals(String mensagem, String mensagem2) {
        assertArrayEquals(mensagem, mensagem2);
    }
	/**
 	 * MÉTODO PARA VALIDAR MENSAGEM
	 * PASSANDO COMO PARAMETRO O TEXTO
	 * EXEMPLO: validaMensagem("texto");
	 * 
	 * @param mensagem
	 */
 	public void validaMensagem(String mensagem) {
		
		try {
			assertArrayEquals(mensagem, mensagem);
			driver.getPageSource().contains(mensagem);
			System.out.println("Mensagem correta!");
		} catch (Error e) {
			geraMensagem("Mensagem Correta:  "+mensagem);
			System.out.println("Mensagem incorreta!");
		}
	}
	public  void geraMensagem (String mensagem) {
		
		Evidencia evidencia = new Evidencia();
		evidencia.setMensagem(mensagem);
		evidencia.setImagem(foto());
		evidencias.add(evidencia);
		System.out.println(mensagem);
	
	}

	/**
	 * MÉTODO USADO PARA STARTAR O BROWSER PASSANDO COMO PARAMETRO A URL
	 * 
	 * @param url
	 * @throws InterruptedException
	 */
	public void startBrowser(String url) throws InterruptedException {
														//CAMINHO ABSOLUTO É COM O C: DA RAIZ
		 												//CAMINHO RELATIVO
		System.setProperty("webdriver.chrome.driver", "..\\testeMestre\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		Logger.getLogger("org.openqa.selenium").setLevel(Level.OFF);
		driver.manage().window().maximize();
		driver.get(url);
		Thread.sleep(5000); 

	}
	/**
	 * METODO USADO PARA TIRAR PRINT DA AÇÃO
	 * DEVE SER COLOCADO APOS O MÉTODO
	 * 
	 * @return
	 */
	public static String foto() {

		File printFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyy-hh-mm-ss");
		Date d = new Date();
		String data = dateFormat.format(d);
		String nomeImagem = data + ".jpeg";

		try {
			FileUtils.copyFile(printFile, new File("C:\\Desenvolvimento\\screenshot\\" + nomeImagem));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return nomeImagem;
	}
	/**
	 * INSERE UM NOME À IMAGEM
	 * 
	 * @param nomeImagem
	 * @return
	 */
	public static String getMensagemEvidencia(String nomeImagem) {
		for(Evidencia evidencia : evidencias) {
			if(evidencia.getImagem().equals(nomeImagem))
				return evidencia.getMensagem();
		}
		return null;
	}
	/**
	 * MÉTODO USADO PARA LER A PLANILHA EXCEL
	 * 
	 * @param nome
	 * @param lin
	 * @param col
	 * @return
	 */
	public String lerExcel(String nome, int lin, int col) {
		String caminho = nome;
		File fp = new File(caminho);
		try {
			Workbook wb = Workbook.getWorkbook(fp);
			Sheet aba = wb.getSheet(0);
			return aba.getCell(col - 1, lin - 1).getContents().toString();
		} catch (Exception ioe) {
			return "Erro de LEITURA.";
		}
	}
	public void logoff(int le, int ce) throws BiffException, InterruptedException, IOException {
		clicarObjeto(By.id(excel.getElementos(le, ce)));
	}
	 /**
	    * CLICA EM UM OBJETO PASSANDO COMO PARAMETRO COMANDOS JAVASCRIPT
	    * Ex.:clicarObjetoJS("passa o by do objeto", "passa o comando JS")
	    * @param by
	    * @param JS
	    */
		public void clicarObjetoJS(By by, String JS) {
			
			WebElement button = driver.findElement(by);
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript(JS, button);
		}
		/*******************************************************************************************
		 * SERVE PARA SELECIONAR O OBJETO COM O BY, PASSANDO COMO PAR�METRO O
		 * BY E O VALOR A SER SELECIONADO EXEMPLO: selecionaComboBy(by.id(""), "teste");
		 * 
		 * @param id
		 * @param valor
		 * @throws InterruptedException
		 */
		public static void selecionaComboBy(By by, String valor) throws InterruptedException {
			
			WebElement element = driver.findElement(by);
			element.click();
			element.sendKeys(valor);
			element.sendKeys(Keys.TAB);
		}
}
