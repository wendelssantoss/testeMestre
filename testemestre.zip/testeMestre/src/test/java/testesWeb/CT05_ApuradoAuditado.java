package testesWeb;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import auxiliaresWeb.GeradorPDF;
import auxiliaresWeb.Menus;
import auxiliaresWeb.SuperClasse;
import jxl.read.biff.BiffException;

/**
 * CENARIO: O AUDITOR SISPL MUDA O STATUS PARA "APURADO AUDITADO"
 * CASO: O AUDITOR SISPL AUDITE A APURAÇÃO
 * E: CONFIRME A MENSAGEM
 * RESULTADO: O STATUS MUDA PARA  "APURADO AUDITADO"
 * 
 * @author f604827
 *
 */
public class CT05_ApuradoAuditado extends SuperClasse{

	@Before
	public void setup() throws InterruptedException {
		startBrowser("https://login.hmp.caixa/auth/realms/intranet/protocol/openid-connect/auth?client_id=cli-web-spl&redirect_uri=http%3A%2F%2Fsbrdeapllx061.extra.caixa.gov.br%3A13580%2Fsispl-gestao-web%2F%3Ferror%3Dinvalid_request%26error_description%3DMissing%2Bparameter%253A%2Bresponse_type&state=e6666fe2-3a7b-4b60-b40c-2c6817266bb1&nonce=8ef2877d-6dfa-4a67-a9bf-0c2d25fcf07d&response_mode=fragment&response_type=code&scope=openid");
	}
	@Test
	public void apuradoAuditado() throws BiffException, IOException, InterruptedException {
		
		acesso();
		Menus.menus();
		
		//AUDITAR APURAÇÃO
		clicaObjExcelName(29, 1);foto();
		//APURAR
		clicaObjExcelName(30, 1);foto();

		//VALIDAR MENSAGEM
		validaMensagem(excel.getElementos(10, 2));foto();
		//SIM
		clicaObjExcelName(26, 1);

		Menus.menus();
		//VALIDAR MENSAGEM
		validaMensagem(excel.getElementos(11, 2));foto();

		//SAINDO DO SISTEMA
		clicaObjExcelJsName(4, 1, 3, 1);

	}
	@After
	public void sair() throws InterruptedException, IOException {
	    Thread.sleep(5000);  
	    driver.quit();
	    GeradorPDF.geraPdf("CT05_ApuradoAuditado.pdf", "Sprint 1");
	   

	}
	public void acesso() throws BiffException, IOException, InterruptedException {
		//MATRICULA
		insereMassaTextoExcelName(1, 7, 3, 8);
		//SENHA
		insereMassaTextoExcelName(4, 7, 6, 8);
		//ENTRAR
		clicaObjExcelName(7, 7);
		Thread.sleep(20000);

	}

}
