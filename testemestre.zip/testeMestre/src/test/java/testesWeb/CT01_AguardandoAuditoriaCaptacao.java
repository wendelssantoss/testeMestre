package testesWeb;

import java.io.IOException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import auxiliaresWeb.GeradorPDF;
import auxiliaresWeb.Menus;
import auxiliaresWeb.SuperClasse;
import jxl.read.biff.BiffException;

/**
 * CENARIO: O PERFIL SUPER GESTOR SISPL MUDA O STATUS PARA "AGUARDANDO AUDITORIA DA CAPTAÇÃO"
 * CASO: O  SUPER GESTOR SISPL CLIQUE EM AUDITAR
 * E: APAREÇA A MENSAGEM DE CONFIRMAÇÃO E O MESMO CONFIRME
 * RESULTADO: O STATUS MUDA PARA "AGUARDANDO AUDITORIA DA CAPTAÇÃO"
 * @author f604827
 *
 */
public class CT01_AguardandoAuditoriaCaptacao extends SuperClasse{

	@Before
	public void setup() throws InterruptedException {
		startBrowser("https://login.hmp.caixa/auth/realms/intranet/protocol/openid-connect/auth?client_id=cli-web-spl&redirect_uri=http%3A%2F%2Fsbrdeapllx061.extra.caixa.gov.br%3A13580%2Fsispl-gestao-web%2F%3Ferror%3Dinvalid_request%26error_description%3DMissing%2Bparameter%253A%2Bresponse_type&state=e6666fe2-3a7b-4b60-b40c-2c6817266bb1&nonce=8ef2877d-6dfa-4a67-a9bf-0c2d25fcf07d&response_mode=fragment&response_type=code&scope=openid");
	}
	
	@Test
	public void aguardandoAuditoriaCaptacao() throws BiffException, IOException, InterruptedException {
		
		
		//ACESSO AO SISTEMA
		acesso();
		Menus.menus();
		
		//VALIDANDO MENSAGEM
		validaMensagem(excel.getElementos(1, 2));foto();
		
		//SAINDO DO SISTEMA
 		clicaObjExcelJsName(4, 1, 3, 1);
	  }
	@After
	public void sair() throws InterruptedException, IOException {
	    Thread.sleep(5000);  
	    driver.quit();
	    GeradorPDF.geraPdf("CT01_AguardandoAuditoriaCaptacao.pdf", "Sprint 1");
	    
	   

	}
	public void acesso() throws BiffException, IOException, InterruptedException {
		//MATRICULA
		insereMassaTextoExcelName(1, 7, 1, 8);foto();
		//SENHA
		insereMassaTextoExcelName(4, 7, 4, 8);foto();
		//ENTRAR
		clicaObjExcelName(7, 7);foto();
		Thread.sleep(20000);

	}

}
