package testesWeb;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import auxiliaresWeb.GeradorPDF;
import auxiliaresWeb.Menus;
import auxiliaresWeb.SuperClasse;
import jxl.read.biff.BiffException;

/**
 * CENARIO: O PERFIL SUPER GESTOR SISPL MUDA O STATUS PARA "SORTEADO AGUARDANDO CONFIRMAÇÃO"
 * CASO: O  SUPER GESTOR SISPL CLIQUE EM AUDITAR SORTEIO
 * E: PREENCHA A OPÇÃO UF E MUNICIPIO
 * E: LOCAL DE SORTEIO DO CAMINHÃO DA SORTE
 * E: INFORME OS SETE NÚMEROS
 * E: CLIQUE EM SALVAR
 * RESULTADO: O STATUS MUDA PARA "SORTEADO AGUARDANDO CONFIRMAÇÃO"
 * 
 * @author f604827
 *
 */
public class CT03_SorteadoAguardandoConfirmacao extends SuperClasse{

	@Before
	public void setup() throws InterruptedException {
		startBrowser("https://login.hmp.caixa/auth/realms/intranet/protocol/openid-connect/auth?client_id=cli-web-spl&redirect_uri=http%3A%2F%2Fsbrdeapllx061.extra.caixa.gov.br%3A13580%2Fsispl-gestao-web%2F%3Ferror%3Dinvalid_request%26error_description%3DMissing%2Bparameter%253A%2Bresponse_type&state=e6666fe2-3a7b-4b60-b40c-2c6817266bb1&nonce=8ef2877d-6dfa-4a67-a9bf-0c2d25fcf07d&response_mode=fragment&response_type=code&scope=openid");
	}
	@Test
	public void sorteadoAguardandoConfirmacao() throws BiffException, IOException, InterruptedException {
		acesso();
		Menus.menus();
		
		//OPÇÃO SORTEIO
		clicaObjExcelCss(8, 1);foto();
		//UF
		SeleCombExcelCss(9, 1, 11, 1);foto();
		//MUNICIPIO
		SeleCombExcelCss(10, 1, 12, 1);foto();
		//OPÇÃO LOCAL DO SORTEIO
		SeleCombExcelCss(13, 1, 14, 1);foto();
		//NUMEROS SORTEADOS 1
		insereMassaTextoExcelName(15, 1, 1, 3);foto();
		//NUMEROS SORTEADOS 2
		insereMassaTextoExcelName(16, 1, 2, 3);
		//NUMEROS SORTEADOS 3
		insereMassaTextoExcelName(17, 1, 3, 3);
		//NUMEROS SORTEADOS 4
		insereMassaTextoExcelName(18, 1, 4, 3);
		//NUMEROS SORTEADOS 5
		insereMassaTextoExcelName(19, 1, 5, 3);
		//NUMEROS SORTEADOS 6
		insereMassaTextoExcelName(20, 1, 6, 3);
		//NUMEROS SORTEADOS 7
		insereMassaTextoExcelName(21, 1, 7, 3);
		//SALVAR
		clicaObjExcelName(22, 1);
		
		//VALIDANDO MENSAGEM
		validaMensagem(excel.getElementos(4, 2));foto();
		//SIM
		clicaObjExcelCss(23, 1);
		
		Menus.menus();
		
		//VALIDANDO MENSAGEM
		validaMensagem(excel.getElementos(5, 2));foto();
		
		//SAINDO DO SISTEMA
		clicaObjExcelJsName(4, 1, 3, 1);

		
	}
	@After
	public void sair() throws InterruptedException, IOException {
	    Thread.sleep(5000);  
	    driver.quit();
	    GeradorPDF.geraPdf("CT03_SorteadoAguardandoConfirmacao.pdf", "Sprint 1");
	   

	}

	public void acesso() throws BiffException, IOException, InterruptedException {
		//MATRICULA
		insereMassaTextoExcelName(1, 7, 1, 8);
		//SENHA
		insereMassaTextoExcelName(4, 7, 4, 8);
		//ENTRAR
		clicaObjExcelName(7, 7);
		Thread.sleep(20000);

	}

}
