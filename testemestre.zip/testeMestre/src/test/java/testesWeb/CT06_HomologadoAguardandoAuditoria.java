package testesWeb;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import auxiliaresWeb.GeradorPDF;
import auxiliaresWeb.Menus;
import auxiliaresWeb.SuperClasse;
import jxl.read.biff.BiffException;

/**
 * CENARIO: O SUPER GESTOR SISPL MUDA O STATUS PARA "HOMOLOGADO AGUARDANDO AUDITORIA"
 * CASO: O SUPER GESTOR SISPL INFORME A ARRECADAÇÃO
 * E: SALVE
 * E: CLIQUE NA OPÇÃO ACOMPANHAR
 * E: CLIQUE NA OPÇÃO HOMOLOGAR
 * E: CLIQUE NA OPÇÃO HOMOLOGAR
 * E: CONFIRME A MENSAGEM
 * RESULTADO: O STATUS MUDA PARA "HOMOLOGADO AGUARDANDO AUDITORIA"
 * 
 * @author f604827
 *
 */

public class CT06_HomologadoAguardandoAuditoria extends SuperClasse{

		@Before
		public void setup() throws InterruptedException {
			startBrowser("https://login.hmp.caixa/auth/realms/intranet/protocol/openid-connect/auth?client_id=cli-web-spl&redirect_uri=http%3A%2F%2Fsbrdeapllx061.extra.caixa.gov.br%3A13580%2Fsispl-gestao-web%2F%3Ferror%3Dinvalid_request%26error_description%3DMissing%2Bparameter%253A%2Bresponse_type&state=e6666fe2-3a7b-4b60-b40c-2c6817266bb1&nonce=8ef2877d-6dfa-4a67-a9bf-0c2d25fcf07d&response_mode=fragment&response_type=code&scope=openid");
		}
		@Test
		public void homologadoAguardandoAuditoria() throws BiffException, IOException, InterruptedException {
			
			acesso();
			Menus.menus();
			
			
			//INFORMAR ARRECADAÇÃO
			clicaObjExcelName(31, 1);foto();
			//VALOR DA ESTIMATIVA
			insereMassaTextoExcelName(32, 1, 8, 3);foto();
			//SALVAR
			clicaObjExcelName(33, 1);
			
			Menus.menus();
			
			//HOMOLOGAR
			clicaObjExcelName(34, 1);foto();
			//HOMOLOGAR
			clicaObjExcelName(34, 1);foto();
			
			//VALIDAR MENSAGEM
			validaMensagem(excel.getElementos(8, 2));foto();
			//SIM
			clicaObjExcelName(26, 1);
			
			Menus.menus();
			//VALIDAR MENSAGEM
			validaMensagem(excel.getElementos(12, 2));foto();

			//SAINDO DO SISTEMA
			clicaObjExcelJsName(4, 1, 3, 1);

		}
		@After
		public void sair() throws InterruptedException, IOException {
		    Thread.sleep(5000);  
		    driver.quit();
		    GeradorPDF.geraPdf("CT06_HomologadoAguardandoAuditoria.pdf", "Sprint 1");
		   

		}
		public void acesso() throws BiffException, IOException, InterruptedException {
			//MATRICULA
			insereMassaTextoExcelName(1, 7, 1, 8);
			//SENHA
			insereMassaTextoExcelName(4, 7, 4, 8);
			//ENTRAR
			clicaObjExcelName(7, 7);
			Thread.sleep(20000);

		}


}
