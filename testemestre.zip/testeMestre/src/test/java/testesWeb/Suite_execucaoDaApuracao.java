package testesWeb;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses(
		{ 
			CT01_AguardandoAuditoriaCaptacao.class, 
			CT02_AguardandoSorteio.class,
			CT03_SorteadoAguardandoConfirmacao.class,
			CT04_ApuradoAguardandoAuditoria.class,
			CT05_ApuradoAuditado.class,
			CT06_HomologadoAguardandoAuditoria.class,
			CT07_HomologadoAuditado.class,
			CT08_Publicarhomologado.class 
			
			}
		)
public class Suite_execucaoDaApuracao {

	static CT01_AguardandoAuditoriaCaptacao ct01 = new CT01_AguardandoAuditoriaCaptacao();
	
	public static void main(String[] args) throws Exception {
		
		SuiteTestes(args[0]);
		
	}
	public static void SuiteTestes(String caminho) throws Exception {

		
		ct01.aguardandoAuditoriaCaptacao();
		
	}

}
