package testesWeb;

import org.junit.Test;

import auxiliaresWeb.SuperClasse;


public class teste extends SuperClasse{

	
	@Test
	public void test() {
		 
		
	}
	
}
