package testesWeb;

import java.io.IOException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import auxiliaresWeb.GeradorPDF;
import auxiliaresWeb.Menus;
import auxiliaresWeb.SuperClasse;
import jxl.read.biff.BiffException;

/**
 * CENARIO: O AUDITOR SISPL MUDA O STATUS PARA AGUARDANDO SORTEIO
 * CASO: O AUDITOR CLIQUE EM AUDITAR
 * E: APAREÇA A MENSAGEM DE CONFIRMAÇÃO E O MESMO CONFIRME
 * RESULTADO: A SITUAÇÃO MUDA PARA O STATUS "AGUARDANDO SORTEIO"
 *  
 * @author f604827
 *
 */
public class CT02_AguardandoSorteio extends SuperClasse{

	
	@Before
	public void setup() throws InterruptedException {
		startBrowser("https://login.hmp.caixa/auth/realms/intranet/protocol/openid-connect/auth?client_id=cli-web-spl&redirect_uri=http%3A%2F%2Fsbrdeapllx061.extra.caixa.gov.br%3A13580%2Fsispl-gestao-web%2F%3Ferror%3Dinvalid_request%26error_description%3DMissing%2Bparameter%253A%2Bresponse_type&state=e6666fe2-3a7b-4b60-b40c-2c6817266bb1&nonce=8ef2877d-6dfa-4a67-a9bf-0c2d25fcf07d&response_mode=fragment&response_type=code&scope=openid");
	}
	@Test
	public void aguardandoSorteio() throws BiffException, IOException, InterruptedException {
		
		acesso();
		Menus.menus();
		
		//AUDITAR
		clicaObjExcelCss(5, 1);foto();
		//AUDITAR
		clicaObjExcelName(2, 1);foto();
		
		//VALIDANDO MENSAGEM
		validaMensagem(excel.getElementos(2, 2));foto();
		//SIM
		clicaObjExcelName(7, 1);foto();
		
		Menus.menus();
		
		//VALIDANDO MENSAGEM
		validaMensagem(excel.getElementos(3, 2));foto();

		//SAINDO DO SISTEMA
		clicaObjExcelJsName(4, 1, 3, 1);

	  }
	@After
	public void sair() throws InterruptedException, IOException {
	    Thread.sleep(5000);  
	    driver.quit();
	    GeradorPDF.geraPdf("CT02_AguardandoSorteio.pdf", "Sprint 1");
	   

	}
	public void acesso() throws BiffException, IOException, InterruptedException {
		//MATRICULA
		insereMassaTextoExcelName(1, 7, 3, 8);
		//SENHA
		insereMassaTextoExcelName(4, 7, 6, 8);
		//ENTRAR
		clicaObjExcelName(7, 7);
		Thread.sleep(20000);

			
	}

}
